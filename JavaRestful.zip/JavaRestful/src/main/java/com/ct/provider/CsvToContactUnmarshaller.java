package com.ct.provider;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import javax.ws.rs.Consumes;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyReader;
import javax.ws.rs.ext.Provider;

import com.ct.entity.Contacts;

@Provider
@Consumes("text/csv")
public class CsvToContactUnmarshaller implements MessageBodyReader<Contacts> {

	@Override
	public boolean isReadable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
		return type.isAssignableFrom(Contacts.class);
	}

	@Override
	public Contacts readFrom(Class<Contacts> type, Type genericType, Annotation[] annotations, MediaType mediaType,
			MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
			throws IOException, WebApplicationException {

		BufferedReader br = new BufferedReader(new InputStreamReader(entityStream));
		String csv = br.readLine();
		String args[] = csv.split(",");
		
		Contacts c = new Contacts();
		
		c.setName(args[0]);
		c.setGender(args[1]);
		c.setEmail(args[2]);
		c.setPhone(args[3]);
		c.setCity(args[4]);
		c.setCountry(args[5]);
		
		return c;
	}

}
