package com.ct.provider;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.ArrayList;

import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyWriter;
import javax.ws.rs.ext.Provider;

import com.ct.entity.Contacts;

@Produces("text/csv")
@Provider
public class ArrayListToCsvMarshaller implements MessageBodyWriter<ArrayList<Contacts>> {

	@Override
	public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
		return type.isAssignableFrom(ArrayList.class);
	}

	@Override
	public long getSize(ArrayList<Contacts> t, Class<?> type, Type genericType, Annotation[] annotations,
			MediaType mediaType) {
		return -1;
	}

	@Override
	public void writeTo(ArrayList<Contacts> tc, Class<?> type, Type genericType, Annotation[] annotations,
			MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream)
			throws IOException, WebApplicationException {

		entityStream.write("ID,name,gemder,email,phone,city,country".getBytes());
		for(Contacts t : tc) {
			String out = String.format("%d%s%s%s%s%s%s", t.getId(),t.getName(),t.getGender(),t.getEmail(),t.getPhone(),t.getCity(),t.getCountry());
			entityStream.write(out.getBytes());
		}
	}



}
