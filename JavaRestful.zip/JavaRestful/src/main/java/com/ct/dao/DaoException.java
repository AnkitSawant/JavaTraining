package com.ct.dao;

public class DaoException extends Exception {

	private static final long serialVersionUID = 1L;

	public DaoException() {
		super();
		
	}

	public DaoException(String arg0) {
		super(arg0);
		
	}

	public DaoException(Throwable arg0) {
		super(arg0);
		
	}

}
