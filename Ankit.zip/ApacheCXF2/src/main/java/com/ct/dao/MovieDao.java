package com.ct.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ct.entity.Movie;
import com.ct.util.DbUtil;

public class MovieDao {
	
	public Movie getMovie(Integer id) throws DaoException {
		
		String sql = "select id, name, director from movies where id='" + id + "'";
		try(
				Connection conn = DbUtil.getConnection();
				PreparedStatement stmt = conn.prepareStatement(sql); 
				
				){
			
			ResultSet rs = stmt.executeQuery(sql);
			
			if(rs.next()) {
				Movie c = toMovie(rs);
				rs.close();
				return c;
			}
			
			rs.close();
		}
		catch(Exception ex) {
			throw new DaoException(ex);
		}
		
		return null;
	}
	
	private Movie toMovie(ResultSet rs) throws SQLException {
		Movie m = new Movie();
		m.setId(rs.getInt("id"));
		m.setName(rs.getString("name"));
		m.setDirector(rs.getString("director"));
		
		return m;
	}

}
