package com.ct.resources;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import com.ct.dao.DaoException;
import com.ct.dao.MovieDao;
import com.ct.entity.Movie;

@Path("/movieservice/")
@Produces("text/xml")
public class MovieResource {

	long currentId = 123;
	//Map<Long, Movie> movies = new HashMap<Long, Movie>();
	
	MovieDao mdao = new MovieDao();
	
	public MovieResource() {
	}
	
	@GET
	@Path("/movie/{id}/")
	public Movie getMovie(@PathParam("id") String id) throws DaoException {
	      Integer idNumber = Integer.parseInt(id);
	      return mdao.getMovie(idNumber);
	  }
	
}
