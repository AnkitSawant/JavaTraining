package com.ct.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ct.dao.MovieDao;
import com.ct.entity.Movie;

@RestController
public class MainController {

	@RequestMapping(value="/")
	public String getHome() {
		return "index";
	}
			
	@RequestMapping(value="/movie", method=RequestMethod.GET)
	public ModelAndView getMovie(@RequestParam("id") int id) {
		
		ApplicationContext ctx=null;
		ModelAndView mv = new ModelAndView();
    	ctx=new ClassPathXmlApplicationContext("springConfig.xml");        
        MovieDao dao=(MovieDao)ctx.getBean("mdao");
        mv.addObject("movie", dao.getMovie(id));
        mv.setViewName("index");
        return mv;
		
	}
	
}
