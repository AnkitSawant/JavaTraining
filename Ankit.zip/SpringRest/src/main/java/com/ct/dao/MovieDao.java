package com.ct.dao;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ct.entity.Movie;


public class MovieDao {
	
	private JdbcTemplate jdbcTemplate;
	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public Movie getMovie(int id) {
		Movie mov=null;
		String sql="SELECT id,name,director FROM movies where id=?";
		mov=(Movie) jdbcTemplate.queryForObject(sql,new Object[]{id},new BeanPropertyRowMapper(Movie.class));
		return mov;
	}

}
