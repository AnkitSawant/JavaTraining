package com.ct.entity;

import org.springframework.stereotype.Component;

@Component
public class Movie {
	private long id;
	private String name;
	private String director;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

}