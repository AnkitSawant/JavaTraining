package com.ct.server;

import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.cxf.jaxrs.lifecycle.SingletonResourceProvider;

import com.ct.entity.Movie;
import com.ct.resources.MovieResource;
import com.fasterxml.jackson.jaxrs.json.JacksonJaxbJsonProvider;

public class Server {
	   public static void main(String[] args) throws Exception {
	      JAXRSServerFactoryBean factory = new JAXRSServerFactoryBean();
	      factory.setResourceClasses(Movie.class);
	      factory.setResourceClasses(MovieResource.class);  
	      factory.setResourceProvider(MovieResource.class,
	         new SingletonResourceProvider(new MovieResource()));
	      factory.setAddress("http://localhost:8081/");
	      
	      JacksonJaxbJsonProvider jacksonJaxbJsonProvider = new JacksonJaxbJsonProvider();
	      factory.setProvider(jacksonJaxbJsonProvider);
	      
	      factory.create();
	      
	      System.out.println("Server ready...");
	      Thread.sleep(5 * 60 * 1000);
	      
	      System.out.println("Server exiting ...");
	      System.exit(0);
	   }
	}
