package com.ct.resources;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.ct.dao.DaoException;
import com.ct.dao.MovieDao;
import com.ct.entity.Movie;

@Path("/movieservice/")
@Produces({"text/xml","application/json"})
public class MovieResource {

	long currentId = 123;
	//Map<Long, Movie> movies = new HashMap<Long, Movie>();
	
	MovieDao mdao = new MovieDao();
	
	public MovieResource() {
	}
	
	@GET
	@Path("/movie")
    @Produces(MediaType.APPLICATION_JSON)
	public Movie getMovie(@QueryParam("id") String id) throws DaoException {
	      Integer idNumber = Integer.parseInt(id);
	      return mdao.getMovie(idNumber);
	  }
	
	@POST
	@Path("/movie")
	@Consumes({"text/xml","application/json"})
	public Movie addMovie(Movie movie) throws DaoException {
		
		return mdao.addMovie(movie);
	}
	
	@PUT
	@Path("/movie/{id}/")
	@Consumes({"text/xml","application/json"})
	public Movie updateMovie(@PathParam("id") String id, Movie movie) throws DaoException {
	      Integer idNumber = Integer.parseInt(id);
	      movie.setId(idNumber);
	      return mdao.updateMovie(movie);
	  }
	
}
