package com.ct.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.ct.entity.Movie;
import com.ct.util.DbUtil;

public class MovieDao {
	
	public Movie getMovie(Integer id) throws DaoException {
		
		String sql = "select id, name, director from movies where id='" + id + "'";
		try(
				Connection conn = DbUtil.getConnection();
				PreparedStatement stmt = conn.prepareStatement(sql); 
				
				){
			
			ResultSet rs = stmt.executeQuery(sql);
			
			if(rs.next()) {
				Movie c = toMovie(rs);
				rs.close();
				return c;
			}
			
			rs.close();
		}
		catch(Exception ex) {
			throw new DaoException(ex);
		}
		
		return null;
	}
	
	private Movie toMovie(ResultSet rs) throws SQLException {
		Movie m = new Movie();
		m.setId(rs.getInt("id"));
		m.setName(rs.getString("name"));
		m.setDirector(rs.getString("director"));
		
		return m;
	}

	public Movie addMovie(Movie movie) throws DaoException {
		
		String sql = "insert into movies(name, director) values (?,?)";
		try(
				Connection conn = DbUtil.getConnection();
				PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				
				){
			
			stmt.setString(1, movie.getName());
			stmt.setString(2, movie.getDirector());
			
			
			stmt.executeUpdate();
			ResultSet keys = stmt.getGeneratedKeys();
			keys.next();
			movie.setId(keys.getInt(1));
			return movie;
			
		}catch(Exception ex) {
			throw new DaoException(ex);
		}
	}

	public Movie updateMovie(Movie movie) throws DaoException {
		String sql = "update movies set name=?, director=? where id=?";
		try(
				Connection conn = DbUtil.getConnection();
				PreparedStatement stmt = conn.prepareStatement(sql); 
				
				){
			
			stmt.setString(1, movie.getName());
			stmt.setString(2, movie.getDirector());
			stmt.setInt(3, (int) movie.getId());
			
			int count = stmt.executeUpdate();
			if(count == 0) {
				throw new DaoException("no record found, invalid id supplied: " + movie.getId());
			}
			
		} catch(Exception ex) {
			throw new DaoException(ex);
		}
		return movie;
	}

}
