package com.ct.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.spi.DirStateFactory.Result;

import com.ct.entity.Contacts;
import com.ct.utils.DbUtils;

public class ContactsDaoImpl implements IContactsDao {

	public Contacts addContact(Contacts contact) throws DaoException {
		
		String sql = "insert into contacts (name, gender, email, phone, city, country) values(?,?,?,?,?,?)";
		
		try{
			Connection connection = DbUtils.getConnection(); 
			PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			stmt.setString(1, contact.getName());
			stmt.setString(2, contact.getGender());
			stmt.setString(3, contact.getEmail());
			stmt.setString(4, contact.getPhone());
			stmt.setString(5, contact.getCity());
			stmt.setString(6, contact.getCountry());
			
			stmt.executeUpdate();
			ResultSet keys = stmt.getGeneratedKeys();
			keys.next();
			contact.setId(keys.getInt(1));
			
			return contact;
		}catch(Exception ex) {
			throw new DaoException(ex);
		}
		
	}

	public Contacts findByID(Integer id) throws DaoException {
		
		String sql = "select * from contacts where id=?";
		
		try(Connection connection = DbUtils.getConnection(); 
				PreparedStatement stmt = connection.prepareStatement(sql);
				){
			
			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();
			if(rs.next()) {
				Contacts contact = toContact(rs);
				rs.close();
				return contact;
			}
			rs.close();
			
		}
		catch(Exception ex) {
			throw new DaoException(ex);
		}
		return null;
	}

	private Contacts toContact(ResultSet rs) throws SQLException {
		Contacts contact = new Contacts();
		contact.setId(rs.getInt("id"));
		contact.setName(rs.getString("name"));
		contact.setEmail(rs.getString("email"));
		contact.setCity(rs.getString("city"));
		contact.setCountry(rs.getString("country"));
		contact.setGender(rs.getString("gender"));
		contact.setPhone(rs.getString("phone"));
		return contact;
	}

	public Contacts updateContact(Contacts contact) throws DaoException {
		
		String sql = "update contacts set name=?, gender=?, emaail=?, phone=?, city=?, counrty=? where id=?";
		
		try(Connection connection = DbUtils.getConnection(); 
				PreparedStatement stmt = connection.prepareStatement(sql);
				){
			
			stmt.setString(1, contact.getName());
			stmt.setString(2, contact.getGender());
			stmt.setString(3, contact.getEmail());
			stmt.setString(4, contact.getPhone());
			stmt.setString(5, contact.getCity());
			stmt.setString(6, contact.getCountry());
			stmt.setInt(7, contact.getId());
			
			int count = stmt.executeUpdate();
			
			if(count == 0 ) {
				throw new DaoException("Invalid id-"+contact.getId());
			}
			return contact;
		}catch(Exception ex) {
			throw new DaoException(ex);
		}
	}

	public void deleteContact(Integer id) throws DaoException {

String sql = "delete from contacts where id=?";
		
		try(Connection connection = DbUtils.getConnection(); 
			PreparedStatement stmt = connection.prepareStatement(sql);
				){
			
			stmt.setInt(1, id);
			
			int count = stmt.executeUpdate();
			
			if(count == 0 ) {
				throw new DaoException("Invalid id-"+id);
			}
		}catch(Exception ex) {
			throw new DaoException(ex);
		}
	}

	public List<Contacts> findAll() throws DaoException {
		
		String sql = "select * from contacts";
		List<Contacts> contacts = new ArrayList<Contacts>();
		
		try(Connection connection = DbUtils.getConnection(); 
			PreparedStatement stmt = connection.prepareStatement(sql);
				){
			
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				contacts.add(toContact(rs));
			}
			
		}
		catch(Exception ex) {
			throw new DaoException(ex);
		}
		return contacts;
	}

	public List<Contacts> findByCity(String city) throws DaoException {
		
		String sql = "select * from contacts where city=?";
		List<Contacts> contacts = new ArrayList<Contacts>();
		
		try(Connection connection = DbUtils.getConnection(); 
				PreparedStatement stmt = connection.prepareStatement(sql);
				){
			
			stmt.setString(1, city);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				contacts.add(toContact(rs));
			}
			
			rs.close();
		}
		catch(Exception ex) {
			throw new DaoException(ex);
		}
		return contacts;
	}

	public List<Contacts> findByCountry(String country) throws DaoException {

		String sql = "select * from contacts where country=?";
		List<Contacts> contacts = new ArrayList<Contacts>();
		
		try(Connection connection = DbUtils.getConnection(); 
			PreparedStatement stmt = connection.prepareStatement(sql);
				){
			
			stmt.setString(1, country);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				contacts.add(toContact(rs));
			}
			
			rs.close();
		}
		catch(Exception ex) {
			throw new DaoException(ex);
		}
		return contacts;
	}

}
