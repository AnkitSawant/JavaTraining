package com.ct;

import javax.websocket.server.PathParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import com.ct.dao.ContactsDaoImpl;
import com.ct.dao.DaoException;
import com.ct.dao.IContactsDao;

@Path("/contacts")
public class ContactResource {

	IContactsDao contactDao = new ContactsDaoImpl();
	
	@GET
	@Produces({"application/json"})
	public Response findAll() throws DaoException {
		
	return Response.ok(contactDao.findAll()).build();
	}
	
	@Path("/{id}")
	@GET
	@Produces({"application/json"})
	public Response findCustomer(@PathParam("id") Integer id) throws DaoException {
		
		System.out.println(id);
	return Response.ok(contactDao.findByID(id)).build();
	}
}
