package com.ct.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.ct.dao.DaoException;

public class DbUtils {

	public DbUtils() {
	}

	public static Connection getConnection() throws DaoException, ClassNotFoundException {
		Connection connection = null;
		FileInputStream fileInputStream=null;
		String databaseConfigFile = "C:\\Users\\ankits7\\Desktop\\java\\com\\RestDemo\\src\\main\\resources\\dbutil.properties";

			try {
				fileInputStream=new FileInputStream(databaseConfigFile);
				Properties property =new Properties();
				property.load(fileInputStream);
				Class.forName(property.getProperty("driver"));
				connection = DriverManager.getConnection(property.getProperty("url"),property.getProperty("username"),property.getProperty("password"));		
				//connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");		
			}
			catch (SQLException exception) {
				throw new DaoException("Unable to connect to database. Contact sanket.");
			} catch (FileNotFoundException exception) {
				throw new DaoException("Database not found. Contact administrator.");
			} catch (IOException exception) {
				throw new DaoException("Unable to connect to database. Contact ankit");
			}
			finally {
				try {
					fileInputStream.close();
				} catch (IOException exception) {
					throw new DaoException("Unable to close DbConfig file.");
				}
				fileInputStream = null;
			}
			
			return connection;
	
}
	
}
