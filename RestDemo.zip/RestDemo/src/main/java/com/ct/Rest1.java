package com.ct;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Path("/hello")
public class Rest1 {

	@GET
	@Produces({"text/plain"})
	public String getHome() {
		return "home";
	}
	
	@GET
	@Produces({"application/xml"})
	public String getHomeXml() {
		return "<?xml version=\"1.0\" ?>\r\n" + 
				"\r\n" + 
				"<greeting>\r\n" + 
				"	<message>HEllo, SAnket</message>\r\n" + 
				"	<from>Ankit</from>\r\n" + 
				"</greeting>";
	}
	
	@GET
	@Produces({"application/json"})
	public String getHomeJson() {
		return "{\r\n" + 
				"	\"message\": \"Hello SAnket\",\r\n" + 
				"	\"from\": \"Ankit\"\r\n" + 
				"}";
	}
}
