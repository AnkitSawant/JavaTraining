package com.ct.HibernateDemo1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.ct.employee.Employee;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Employee emp = new Employee();
    	//emp.setEmpId(1002);
    	emp.setName("Sanket");
    	emp.setDesignation("TSD");
    	Configuration cf = new Configuration();
    	cf.configure("hibernate.cfg.xml");
    	SessionFactory sf =  new Configuration().configure().buildSessionFactory();
    	Session session = sf.openSession();
    	session.beginTransaction();
    	Transaction tx = session.getTransaction();
    	session.save(emp);
    	//emp.setName("Onkar");
    	//Employee e = (Employee)session.get(Employee.class,1001);
    	//e.setDesignation("COO");
    	tx.commit();
    	/*session.evict(e);
    	e.setName("Kamlesh");
    	session.update(e);
    	tx.commit();*/
    	session.close();
    }
}
