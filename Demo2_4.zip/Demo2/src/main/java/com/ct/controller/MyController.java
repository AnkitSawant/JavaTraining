package com.ct.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;
import com.ct.employee.Employee;
import com.ct.mobilemanagementservice.service.EmployeeServiceImpl;

@Controller
public class MyController {
	
	@Autowired
	EmployeeServiceImpl employeeService;
	
	String currentDirectory = System.getProperty("user.dir");
	
	@RequestMapping("/")
	public String getHomePage() {
		return "index";
	}
	
	@RequestMapping("/add")
	public ModelAndView add() {
		ModelAndView mvc = new ModelAndView();
		mvc.addObject("employee", new Employee());
		mvc.setViewName("add");
		return mvc;
	}
	
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public String register(@RequestParam("file") CommonsMultipartFile file, @ModelAttribute("employee") Employee employee,HttpSession session ) {
		String path=session.getServletContext().getRealPath("/");  
		
        String filename=file.getOriginalFilename();  
          
        System.out.println(path+" "+filename);  
        try{  
	        byte barr[]=file.getBytes();  
	          
	        BufferedOutputStream bout=new BufferedOutputStream(  
	                 new FileOutputStream(path+"/"+filename));  
	        bout.write(barr);  
	        bout.flush();  
	        bout.close();  
          
        }catch(Exception e){System.out.println(e);}
		employeeService.addEmployee(employee);
		System.out.println("Added");
		return "index";
	}
	
	@RequestMapping("/searchById")
	public String searchById() {
		return "search";
	}
	
	@RequestMapping(value="/search",method=RequestMethod.POST)
	public ModelAndView search(@RequestParam("id") Integer empId) {
		Employee employee = employeeService.searchById(empId);
		ModelAndView mvc = new ModelAndView();
		mvc.addObject("employee", employee);
		mvc.setViewName("index");
		return mvc;
	}
	@RequestMapping("/displayAll")
	public ModelAndView displayAll() {
		
		List<Employee> employeeList;
		employeeList = employeeService.displayAll();
		ModelAndView mvc = new ModelAndView();
		mvc.addObject("employeeList", employeeList);
		mvc.setViewName("display");
		return mvc;
	}
	@RequestMapping("/upload")
	public String upload() {
		return "upload";
	}
	
	@RequestMapping("/delete")
	public String delete() {
		return "delete";
	}
	
	@RequestMapping(value="/delete",method=RequestMethod.POST)
	public String deleteEmployee(@RequestParam("Id") Integer employeeId, HttpServletRequest request) {
		employeeService.delete(employeeId);
		request.setAttribute("message", "Employee with id "+employeeId+" deleted.");
		return "index";
	}
	/*@RequestMapping(value="/upload",method=RequestMethod.POST)
	public String fileUpload(HttpServletRequest request, HttpSession session,@RequestParam("name") String username) {
		if(ServletFileUpload.isMultipartContent(request)){
            try {
            	request.removeAttribute("name");
                List<FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);
                for(FileItem item : multiparts){
                    if(!item.isFormField()){
                        String name = new File(item.getName()).getName();
                        
                        String path = "C:\\Users\\trainingvdi\\Desktop";
                        System.out.println("name "+name);
                        item.write(
                          new File(path + File.separator + name));
                    }
                }
               request.setAttribute("message", "Hello " +username+ " File Uploaded Successfully");
            } catch (Exception ex) {
               request.setAttribute("message", "File Upload Failed due to " + ex);
            }
		}
            else{
                request.setAttribute("message",
                       "Sorry this Servlet only handles file upload request");
            }

		return "index";
	}*/
	
	@RequestMapping(value="/upload",method=RequestMethod.POST)
	public String fileUpload(@RequestParam("file") CommonsMultipartFile file,@RequestParam("name") String username, HttpSession session, HttpServletRequest request) {

		String path=session.getServletContext().getRealPath("/");  
		
        String filename=file.getOriginalFilename();  
          
        System.out.println(path+" "+filename);  
        try{  
	        byte barr[]=file.getBytes();  
	          
	        BufferedOutputStream bout=new BufferedOutputStream(  
	                 new FileOutputStream(path+"/"+filename));  
	        bout.write(barr);  
	        bout.flush();  
	        bout.close();  
          
        }catch(Exception e){System.out.println(e);}  
        request.setAttribute("message", "Hello "+username+" uploaded.");
		return "index";
	}
}
