package com.ct.mobilemanagementservice.service;

import java.util.*;

import org.springframework.stereotype.Component;

import com.ct.employee.Employee;
//import com.ct.mobilemanagementservice.mobile.Mobile;

@Component
public interface IEmployeeService {

	public boolean addEmployee(Employee m);
	
	public Employee searchById(int mobId);
	
	public List<Employee> displayAll();
	
//	public String deleteMobile(int mobId);
	
}
