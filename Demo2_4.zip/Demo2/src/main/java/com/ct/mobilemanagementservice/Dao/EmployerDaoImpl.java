package com.ct.mobilemanagementservice.Dao;

import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;

import com.ct.employee.Employee;
import com.ct.util.HibernateUtil;

//import com.ct.mobilemanagementservice.mobile.Mobile;

@Component
public class EmployerDaoImpl implements IEmployeeDaO {
	
/*	private JdbcTemplate jdbcTemplate;

	@Autowired
    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }*/

	@Override
	public List<Employee> displayAll() {
		/*String query = "SELECT * FROM employee1";
		List<Employee> employeeList = (List<Employee>) jdbcTemplate.query(query, new BeanPropertyRowMapper(Employee.class));
		return employeeList;*/
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Transaction tx = session.getTransaction();
		Criteria criteria = session.createCriteria(Employee.class);
		List<Employee> employeeList = criteria.list();
		session.close();
		return employeeList;
	}

	@Override
	public boolean addEmployee(Employee employee) {
		
		/*String query = "INSERT INTO employee1 VALUES (?,?,?,?,?)";
		int status = jdbcTemplate.update(query, new Object[] {employee.getEmployeeId(),employee.getName(),employee.getDesignation(),employee.getEmail(),employee.getPassword()});
		if(status == 1) {
			return true;
		}
		else {
			return false;
		}*/
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Transaction tx = session.getTransaction();
		session.save(employee);
		tx.commit();
		session.close();
		return true;
	}

	@Override
	public Employee searchById(int empId) {

		/*String query = "SELECT * FROM employee1 WHERE employeeId = ?";
		return (Employee) jdbcTemplate.queryForObject(query, new Object[] {empId}, new BeanPropertyRowMapper());
		*/
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Transaction tx = session.getTransaction();
		Employee employee = (Employee)session.get(Employee.class, empId);
		session.close();
		return employee;
	}

	@Override
	public void delete(Integer employeeId) {
		
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Transaction tx = session.getTransaction();
		session.delete(session.get(Employee.class, employeeId));
		tx.commit();
		session.close();
	}

}
