package com.ct.dao;

import java.util.List;

import javax.sql.DataSource;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.ct.mobile.Mobile;
import com.ct.util.HibernateUtil;

@Component
public class MobileDao {

	private JdbcTemplate jdbcTemplate;
	
	@Autowired
    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }
	
	public boolean add(Mobile mobile) {
		
		/*String query="INSERT INTO mobile (Name,Price,Quantity,Description,Discount) VALUES (?,?,?,?,?)";
		int status = jdbcTemplate.update(query, new Object[] {mobile.getName(),mobile.getPrice(),mobile.getQuantity(),mobile.getDescription(),mobile.getDiscount()});
		if(status == 1) {
			return true;
		}
		else {
			return false;
		}
		}*/
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Transaction tx = session.getTransaction();
		session.save(mobile);
		tx.commit();
		session.close();
		return true;
	}
		
	public List<Mobile> displayAll() {
		
		String query="SELECT * FROM mobile";
		List<Mobile> mobileList = jdbcTemplate.query(query, new BeanPropertyRowMapper());
		return mobileList;
	}
}
