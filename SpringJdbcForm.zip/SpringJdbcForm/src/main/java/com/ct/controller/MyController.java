package com.ct.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ct.dao.MobileDao;
import com.ct.mobile.Mobile;

@Controller
public class MyController {
	
	@Autowired
	private MobileDao mobileDao;

	@RequestMapping("/")
	public ModelAndView getHomePage() {
		Mobile mobile = new Mobile();
		ModelAndView mv = new ModelAndView();
		mv.addObject("mobile",mobile);
		mv.setViewName("home");
		return mv;
	}

	@RequestMapping(value="/add",method=RequestMethod.POST)
	public @ResponseBody ModelAndView add(@RequestBody @Valid @ModelAttribute("mobile") Mobile mobile, BindingResult br) {
		
		ModelAndView mv = new ModelAndView();
		System.out.println(mobile);
		if(!br.hasErrors()) {
			if(mobileDao.add(mobile)) {
				mv.addObject("message", "Mobile added successfully");
			}
			else {
				mv.addObject("message", "Mobile " + mobile.getName()+" is not added.");
			}
		}
		mv.setViewName("home");
		return mv;
	}
	
	@RequestMapping("/display")
	public @ResponseBody List<Mobile> displayAll() {
		
		return mobileDao.displayAll();
	}
}
