package com.ct.mobile;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "mobile", schema="test")
public class Mobile {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int mobileId;
	@NotEmpty(message="Name cannot be empty.")
	@Size(min=3, max=16, message="Name must be atleast 3 characters and atmost 16.")
	private String name;
	@NotNull(message="Price cannot be empty.")
	private Float price;
	@NotEmpty(message="Quantity cannot be empty.")
	private String quantity;
	@NotEmpty(message="Description cannot be empty.")
	@Size(min=3, max=16, message="Description must be atleast 3 characters and atmost 16.")
	private String description;
	@NotEmpty(message="Discount cannot be empty.")
	private String discount;
	
	public Mobile() {
		
	}
	
	public Mobile(String name, Float price, String quantity, String description, String discount) {
		this.name = name;
		this.price = price;
		this.quantity = quantity;
		this.description = description;
		this.discount = discount;
	}

	

	public int getMobileId() {
		return mobileId;
	}

	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDiscount() {
		return discount;
	}

	public void setDiscount(String discount) {
		this.discount = discount;
	}

	@Override
	public String toString() {
		return "Mobile [mobileId=" + mobileId + ", name=" + name + ", price=" + price + ", quantity=" + quantity
				+ ", description=" + description + ", discount=" + discount + "]";
	}

	
	
}
