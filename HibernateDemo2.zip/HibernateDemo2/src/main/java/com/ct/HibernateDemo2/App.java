package com.ct.HibernateDemo2;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projections;
import org.hibernate.transform.ResultTransformer;
import org.hibernate.transform.Transformers;

import com.ct.employee.Employee;

public class App 
{
    public static void main( String[] args )
    {

    	SessionFactory sf =  new Configuration().configure().buildSessionFactory();
    	Session session = sf.openSession();
    	session.beginTransaction();
    	Transaction tx = session.getTransaction();
    	
    	Criteria criteria = session.createCriteria(Employee.class);
    	//criteria.setProjection(Projections.property("name"));
    	criteria.setProjection(Projections.projectionList().add(Projections.property("name"),"name")
    			.add(Projections.property("designation"),"designation"));
    	criteria.setResultTransformer(Transformers.aliasToBean(Employee.class));
    	
    	System.out.println(criteria.list());
    	
    	session.close();
    }
}
