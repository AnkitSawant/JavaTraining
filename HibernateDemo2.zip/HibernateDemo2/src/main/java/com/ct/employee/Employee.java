package com.ct.employee;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "emp", schema="test")
public class Employee {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int empId;
	private String name;
	private String designation;
	
	public Employee() {
		
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	@Override
	public String toString() {
		if(empId == 0) {
			return "Employee [name=" + name + ", designation=" + designation + "]";
		}
		else if(name == null) {
			return "Employee [empId=" + empId + ", designation=" + designation + "]";
		}
		else if(designation == null) {
			return "Employee [empId=" + empId + ", name=" + name + "]";
		}
		else {
		return "Employee [empId=" + empId + ", name=" + name + ", designation=" + designation + "]";
		}
		//return "Employee [empId=" + empId + ", name=" + name + ", designation=" + designation + "]";
	}
	
}
