

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ct.desktopmanagement.exception.DesktopException;
import com.ct.desktopmanagement.service.DesktopServiceImpl;
import com.ct.desktopmanagement.service.IDesktopService;

/**
 * Servlet implementation class MyController
 */
@WebServlet("/MyController")
public class MyController extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		IDesktopService desktopService = new DesktopServiceImpl();
		HttpSession session = null;
		String username;
		String password;
		/*String username = req.getParameter("username");
		String password = req.getParameter("password");
		HttpSession session = null;
		String msg = "Logged in successfully ";
		String errmsg = "Invalid username or password";
		RequestDispatcher rd =null;
		System.out.println(req.getRequestURL());
		if("admin".equals(username) && "admin".equals(password)) {
			session = req.getSession(true);
			session.setAttribute("msg", msg);
			session.setAttribute("username", username);
			resp.sendRedirect("Success.jsp");
		}
		else {
			rd = req.getRequestDispatcher("login.jsp");
			req.setAttribute("msg", errmsg);
			rd.forward(req, resp);
			
		}*/
		/*PrintWriter out = resp.getWriter();
		out.println(req.getParameter("name"));
		
		if("adminLogin".equals(req.getParameter("name"))){
			out.println("Admin login");
		}
		else if("userLogin".equals(req.getAttribute("name"))) {
			out.println("User login");
		}
		else if("userSignup".equals(req.getAttribute("name"))){
			out.println("User Signup");
			}
		else {
			out.println("eror");
		}*/
		
		switch (req.getParameter("name")){
			case "adminLogin":
				username = req.getParameter("username");
				password = req.getParameter("password");
			try {
				if(desktopService.checkIfAdmin(username, password)) {
					session = req.getSession(true);
					
				}
			} catch (DesktopException e) {
				
			}
				
			case "userLogin":
				username = req.getParameter("username");
				password = req.getParameter("password");
			try {
				desktopService.checkIfUser(username, password);
			} catch (DesktopException e) {
				
			}
				
			case "userSignup":
				
			default:
		}
	}

}
