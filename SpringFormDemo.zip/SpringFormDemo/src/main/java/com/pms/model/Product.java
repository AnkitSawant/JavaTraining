package com.pms.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Product {
	private int id;
	@Size(min=5, max=30,message="product name cannot be less than 5")
	private String prodName;
	@NotNull(message="field is mandatory")
	private String price;
	private String prodQty;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getProdQty() {
		return prodQty;
	}
	public void setProdQty(String prodQty) {
		this.prodQty = prodQty;
	}
	
	public Product() {
	}

}
