package com.ct;


@org.springframework.web.bind.annotation.RestController
public class RestController {

}
